import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import {  Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';
//import {switchMap } from 'rxjs/operators';
 
import 'rxjs'; 
import {LoginModel } from './login.model';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login=new LoginModel()
data:any;
public isLogedIn=false;
status:any;
message=5;
name='';
//users$:Observable<Array<{name:string}>>
//message:any;
//refresh=new BehaviorSubject<boolean>(true);
  constructor(private dataService:DataService,private router:Router) { 
    
    if(localStorage.getItem("auth_token"))
    {
     this.isLogedIn=true;
     this.router.navigate(["/home"]);
    }
    else
    {
      this.isLogedIn=false;
    }}

  ngOnInit(): void {
    console.log(localStorage.getItem("auth_token"));
    this.dataService.setMessage(this.message);
  }
  auth_token:any;
  submit(data:any)
  {
    this.login={
    email:data.email,
    password:data.password
    };
  this.dataService.login(this.login).subscribe((res:any)=>{
    this.auth_token=res['success']['token'];
    //console.warn(this.auth_token)
    localStorage.setItem("auth_token",this.auth_token);


    this.dataService.getToken(this.auth_token);

    //console.log(res);
    this.dataService.setLoading(false);
    console.log(this.dataService.getLoading());
   
    this.router.navigate(["/home"]);
  }),((error:any)=>{
   console.log(error)
});

  }



}

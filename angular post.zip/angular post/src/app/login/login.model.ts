export class LoginModel
{
	email:any;
	password:any;
}
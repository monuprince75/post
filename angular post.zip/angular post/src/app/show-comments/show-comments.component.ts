import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import {ActivatedRoute} from '@angular/router';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-show-comments',
  templateUrl: './show-comments.component.html',
  styleUrls: ['./show-comments.component.css']
})
export class ShowCommentsComponent implements OnInit {
data:any;
 constructor( private dataService:DataService,private router:Router,private route:ActivatedRoute) {
}

  ngOnInit(): void {
  	this.getComment();
  }
  getComment()
  {
  	this.dataService.getComments(this.route.snapshot.params.id).subscribe((res)=>{
  this.data=res;
  console.log(this.data)
  });
  }
}


import { Component, OnInit } from '@angular/core';
import { Comment } from './comment.model';
import {  Router } from '@angular/router';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
import {ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
data:any;
comment=new Comment();
constructor(private dataservice:DataService,private router:ActivatedRoute,private rout:Router)  { }

  ngOnInit(): void {
  }




addComment(data:any)
{
console.log(this.router.snapshot.params.id);
console.warn(data)
    this.comment={
    comments:data
    };

	this.dataservice.submitComment(this.comment,this.router.snapshot.params.id).subscribe((res:any)=>{
  this.data=res;
 
   console.log(this.data);
   this.rout.navigate(["/home"]);

   
 })
 }


}



 


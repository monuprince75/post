import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
import 'rxjs'; 
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
data:any;



  constructor(private dataService:DataService) { }

  ngOnInit(): void {
  this.getLoginData();
  }



  getLoginData()
  {
  this.dataService.getData().subscribe((res)=>{
  this.data=res;


  console.log(this.data);
   })

  }

}

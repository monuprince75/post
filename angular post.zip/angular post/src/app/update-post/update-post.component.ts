import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import {ActivatedRoute} from '@angular/router';
import {FormGroup,FormControl} from '@angular/forms';
import { UpdatePost } from './update-post.model';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-update-post',
  templateUrl: './update-post.component.html',
  styleUrls: ['./update-post.component.css']
})
export class UpdatePostComponent implements OnInit {
data:any;
id:any;
updateP=new UpdatePost();
editBlog=new FormGroup({
title:new FormControl(''),
content:new FormControl('')
})
  constructor( private dataService:DataService,private router:ActivatedRoute,private rout:Router) { }

  ngOnInit(): void {
  	this.getBlogData();
  	console.warn(this.router.snapshot.params.id)
  	this.id=this.router.snapshot.params.id;
  }
 getBlogData()
  { 
     this.dataService.idBlog(this.router.snapshot.params.id).subscribe((res:any)=>{
   //   this.data=res;
    console.warn(res);
    if(res&&res.data)
    {

    	 this.editBlog=new FormGroup({
title:new FormControl(res.data['title']),
content:new FormControl(res.data['content'])
});
    
    }
     console.log(this.editBlog.controls['title'].value)
     console.log(res);

});
 }
updateBlog(data:any)
{
  console.log(data);
this.updateP={
	
    title:data.title,
    content:data.content,
    };
    console.log(this.updateP);

	this.dataService.updateBlog(this.updateP,this.router.snapshot.params.id).subscribe((res:any)=>{
  this.data=res;
 this.updateP=new UpdatePost();
   console.log(this.data);
   this.rout.navigate(["/home"]);
 })

console.log(data);
alert("Blog Submitted")
}



}


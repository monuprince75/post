export class UpdatePost
{
	title:any;
	content:any;
}
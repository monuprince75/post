import { Component ,OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { DataService } from './services/data.service';
import { Observable } from 'rxjs';
import { ValidatorFn, AbstractControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import {switchMap } from 'rxjs/operators';
 import { BehaviorSubject } from 'rxjs';
import 'rxjs'; 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
message:any;
isLogedIn=false;

LoginStatus$=new BehaviorSubject<boolean>(true);
//Username$:Observable<string>;

refresh=new BehaviorSubject<boolean>(true);
  constructor(private dataService:DataService,private router:Router,) { 
if(localStorage.getItem("auth_token"))
    {
     this.isLogedIn=true;
     this.router.navigate(["/home"]);
    }
    else
    {
      this.isLogedIn=false;
    }}

 data:any;

islogin=false;
  title = 'test-app';
ngOnInit(): void {

  }
  logout()
 {

   this.dataService.logoutUser().subscribe(res=>{
   this.data=res;
   alert("Successfully Logged ");
   //console.warn('auth_token');
   localStorage.removeItem('auth_token');
   this.isLogedIn=false;
   this.router.navigate(['/login']);
 })
 }
	
 
}

 import { Injectable } from '@angular/core';
import { Router } from '@angular/router'; 
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError,Subject } from 'rxjs';
import { catchError, retry} from 'rxjs/operators';

import { map} from 'rxjs/operators';

import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})


export class DataService {
  errorData:any;
  log:any;
token:any;
isLogedIn=false
loading:boolean=true;
message:any

httpOptions:any;

 data:any;
  constructor(private httpClient:HttpClient ,private router: Router) { 

this.httpOptions = {
     headers: new HttpHeaders({
       'Content-Type':  'application/json',
       'Access-Control-Allow-Origin': '*',
        'Authorization': 'Bearer ' + this.token,
     })
   };
  }
  getData()
  {
  
return this.httpClient.get('http://localhost/Laravel/project1/public/')
       
       
       
  }
  getBlog()
  {
    this.httpOptions = {
headers: new HttpHeaders()
.set('Authorization', `Bearer ${localStorage.getItem('auth_token')}`)
}
this.httpOptions.headers.Authorization = 'Bearer ' + localStorage.getItem('auth_token');
    return this.httpClient.get('http://localhost:8000/api/blog',this.httpOptions);
       
  }
  getUserBlog()
  {
    this.httpOptions = {
headers: new HttpHeaders()
.set('Authorization', `Bearer ${localStorage.getItem('auth_token')}`)
}
this.httpOptions.headers.Authorization = 'Bearer ' + localStorage.getItem('auth_token');
    return this.httpClient.get('http://localhost:8000/api/userBlog',this.httpOptions);
       
  }


getToken(token:any)
{
this.token=token;
}

  setLoading(loading:any) {
     this.loading = loading;
   }
  getLoading() {
    return this.loading;
   }

registerUser(data:any)
{

return this.httpClient.post('http://127.0.0.1:8000/api/register',data,this.httpOptions );
localStorage.removeItem('auth_token');
   this.router.navigate(['/home']);
}


addBlog(data:any)
{

return this.httpClient.post('http://localhost:8000/api/addBlog',data,this.httpOptions );

}
updateBlog(data:any,post_id:any)
{
  
   this.httpOptions = {
headers: new HttpHeaders()
.set('Authorization', `Bearer ${localStorage.getItem('auth_token')}`)
}

return this.httpClient.post('http://localhost:8000/api/update/'+post_id,data,this.httpOptions );

}

login(data:any)
{

this.log=this.httpClient.post('http://127.0.0.1:8000/api/login',data,this.httpOptions );
 
 
 return this.log;
}

deleteBlog(data:any)
{
   this.httpOptions = {
headers: new HttpHeaders()
.set('Authorization', `Bearer ${localStorage.getItem('auth_token')}`)
}

 return this.httpClient.post('http://127.0.0.1:8000/api/delete',data,this.httpOptions )

            .pipe(map((data: any) => data.result ), 
                  catchError(error => { return throwError('Its a Trap!')})
            );

}
idBlog(data:any)
{
    this.httpOptions = {
headers: new HttpHeaders()
.set('Authorization', `Bearer ${localStorage.getItem('auth_token')}`)
}
this.httpOptions.headers.Authorization = 'Bearer ' + localStorage.getItem('auth_token');
    return this.httpClient.get('http://localhost:8000/api/singleBlog/'+data,this.httpOptions);
      
}

logoutUser()
{

  this.httpOptions = {
headers: new HttpHeaders()
.set('Authorization', `Bearer ${localStorage.getItem('auth_token')}`)
}
   this.httpOptions.headers.Authorization = 'Bearer ' + localStorage.getItem('auth_token');
   return this.httpClient.post('http://127.0.0.1:8000/api/logout',{},this.httpOptions);
 

}

 submitComment(data:any,post_id:any)
 {
   console.warn(post_id)
    this.httpOptions = {
headers: new HttpHeaders()
.set('Authorization', `Bearer ${localStorage.getItem('auth_token')}`)
}
this.httpOptions.headers.Authorization = 'Bearer ' + localStorage.getItem('auth_token');
    return this.httpClient.post('http://localhost:8000/api/comment/'+post_id,data,this.httpOptions)
.pipe(map((data: any) => data.result ), 
                  catchError(error => { return throwError('Its a Trap!')})
            );

 }
 getComments(post_id:any)
 {
   console.warn(post_id);
this.httpOptions = {
headers: new HttpHeaders()
.set('Authorization', `Bearer ${localStorage.getItem('auth_token')}`)
}
this.httpOptions.headers.Authorization = 'Bearer ' + localStorage.getItem('auth_token');
    return this.httpClient.get('http://localhost:8000/api/getComments/'+post_id,this.httpOptions);
       

 }

  logout() {
    localStorage.removeItem('currentUser');
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {

      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {

      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }

    // return an observable with a user-facing error message
    this.errorData = {
      errorTitle: 'Oops! Request for document failed',
      errorDesc: 'Something bad happened. Please try again later.'
    };
    return throwError(this.errorData);
  }

  isLoged=new Subject<any>();


setMessage(data:any)
{
this.message=data
}
getMessage()
{
return this.message
}

}



  



import { Component, OnInit } from '@angular/core';
import { Blog } from './blog.model';
import {  Router } from '@angular/router';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
import 'rxjs';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {
isLogedIn=false;
data:any;
blog=new Blog();
message:any;
  constructor(private dataservice:DataService,private router:Router) {  
    if(localStorage.getItem("auth_token"))
    {
     this.isLogedIn=true;
    }
    else
    {
      this.isLogedIn=false;
    }}
 
  ngOnInit(): void {
  }

  addBlog(data:any)
{
this.blog={
    title:data.title,
    content:data.content,
    };


	this.dataservice.addBlog(this.blog).subscribe((res:any)=>{
  this.data=res;
  this.message=this.data.message;
  this.blog=new Blog();
   console.log(this.data);
   this.router.navigate(["/user-post"]);
 })

console.log(data);
alert("Blog Submitted")
}


}


export class Blog
{
	title:any;
	content:any;
}
import { Component, OnInit } from '@angular/core';
import { Register } from './register.model';
import {  Router } from '@angular/router';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
import 'rxjs'; 

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
data:any;
isLogedIn=false;
register=new Register();
message:any;
  constructor(private dataservice:DataService,private router:Router) {
  if(localStorage.getItem("auth_token"))
    {
     this.isLogedIn=true;
     this.router.navigate(["/login"]);
    }
    else
    {
      this.isLogedIn=false;
    } }
 

  ngOnInit(): void {
  }

submit(data:any)
{
    this.register={
    name:data.name,
    email:data.email,
    password:data.password
    };

	this.dataservice.registerUser(this.register).subscribe((res:any)=>{
  this.data=res;
  this.message=this.data.message;
   console.log(this.data);
   this.router.navigate(["/home"]);

   
 })
 }

}

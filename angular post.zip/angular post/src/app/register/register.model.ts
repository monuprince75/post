export class Register
{
	name:any;
	email:any;
	password:any;
}
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {HomeComponent } from './home/home.component';
import {LogoutComponent } from './logout/logout.component';
import { BlogComponent } from './blog/blog.component';
import {UserPostComponent } from './user-post/user-post.component';
import {UpdatePostComponent } from './update-post/update-post.component';
import {CommentComponent} from './comment/comment.component';
import {ShowCommentsComponent} from './show-comments/show-comments.component';
const routes: Routes = [
{
	path:'login',
	component:LoginComponent

},
{
	path:'register',
	component:RegisterComponent

},
{
	path:'home',
	component:HomeComponent

},
{
	path:'logout',
	component:LogoutComponent

},
{
	path:'blog',
	component:BlogComponent

},
{
	path:'user-post',
	component:UserPostComponent

},
{
	path:'update-post/:id',
	component:UpdatePostComponent

},
{
	path:'comment/:id',
	component:CommentComponent

},
{
	path:'show-comments/:id',
	component:ShowCommentsComponent

}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


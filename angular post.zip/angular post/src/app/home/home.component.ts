import { Component, OnInit } from '@angular/core';
import { Home } from './home.model';
import { Comment } from './comment.model';

import { Delete } from './delete.model';
import {  Router } from '@angular/router';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
import 'rxjs'; 
import {ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
data:any;
data1:any;
post_id:any;
message:any
myform:any
del=new Delete();
comment=new Comment();
com=new Comment();
isLogedIn=false;
home=new Home();
constructor(private dataService:DataService,private router:Router,private route:ActivatedRoute) { 
if(localStorage.getItem("auth_token"))
    {
     this.isLogedIn=true;
     
    }
    else
    {
      this.isLogedIn=false;
      this.router.navigate(["/login"]);
    }

}

  ngOnInit(): void {

this.message=this.dataService.getMessage()
  this.getBlogData();
  }

  getBlogData()
  {
  this.dataService.getBlog().subscribe((res)=>{
  this.data=res;
  this.post_id=this.data.id;
   })

  }


addComment(data:any,post_id:any)
{
console.log(post_id);
//this.post_id1=post_id;
console.warn("hello");
    this.comment={
    comments:data
    };

  this.dataService.submitComment(this.comment,post_id).subscribe((res:any)=>{
  this.getComment(post_id)

  //this.data=res;
   //this.router.navigate(["/home"]);
 //this.myform.reset();
   
 });
 }
  getComment(post:any)
  {
    // console.log(this.post_id1);
     console.log(post);
    this.dataService.getComments(post).subscribe((res)=>{
  this.data1=res;
  console.warn(this.data1)
  });
  }


  deleteId(id:any)
  {
    this.del={
    id:id
    };

this.dataService.deleteBlog(this.del).subscribe((res:any)=>{
  this.data=res;
//this.router.navigate(["/home"]);
});
  }

  
}


  


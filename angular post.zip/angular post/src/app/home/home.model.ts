export class Home
{
	id:any
}

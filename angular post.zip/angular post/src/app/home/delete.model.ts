export class Delete
{
	id:any
}
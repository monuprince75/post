export class Comments
{
	id:any;
}
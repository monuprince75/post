export class Comment
{
	comments:any;
}

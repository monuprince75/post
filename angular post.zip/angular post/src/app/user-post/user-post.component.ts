import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { UserPost } from './user-post.model';
import { DataService } from '../services/data.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-user-post',
  templateUrl: './user-post.component.html',
  styleUrls: ['./user-post.component.css']
})
export class UserPostComponent implements OnInit {
data:any;
uPost=new UserPost();
isLogedIn=false;
  constructor( private dataService:DataService,private router:Router) {
if(localStorage.getItem("auth_token"))
    {
     this.isLogedIn=true;
     
    }
    else
    {
      this.isLogedIn=false;
      this.router.navigate(["/login"]);
    }
   }

  ngOnInit(): void {
  	this.getBlogData();
  }
getBlogData()
  {
  this.dataService.getUserBlog().subscribe((res)=>{
  this.data=res;
   })

  }
deleteId(id:any)
  {
  	this.uPost={
    id:id
    };

this.dataService.deleteBlog(this.uPost).subscribe((res:any)=>{
  this.data=res;
this.router.navigate(["/home"]);
});
  }


}

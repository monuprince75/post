export class UserPost
{
	id:any;
}